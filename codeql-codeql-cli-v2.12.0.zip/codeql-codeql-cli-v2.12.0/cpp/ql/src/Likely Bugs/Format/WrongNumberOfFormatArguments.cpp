int main() {
  printf("%d, %s\n", 42); // Will crash or print garbage
  return 0;
}
