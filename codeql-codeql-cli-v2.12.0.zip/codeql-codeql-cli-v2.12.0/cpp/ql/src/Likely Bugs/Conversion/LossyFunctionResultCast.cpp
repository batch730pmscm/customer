double getWidth();

void f() {
	int width = getWidth();
	
	// ...
}
