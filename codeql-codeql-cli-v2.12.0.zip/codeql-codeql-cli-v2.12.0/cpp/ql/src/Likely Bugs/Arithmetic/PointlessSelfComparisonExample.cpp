typedef int T;

bool checkOverflow(T x) {
  return (x == (int)x);  // Always returns true.
}
