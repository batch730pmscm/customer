void f()
{
    for (signed char i = 0; i < 100; i--)
    {
        // code ...
    }
}