//empty then and else branches, will not do anything (other than the check)
if (check(i)) {
}
