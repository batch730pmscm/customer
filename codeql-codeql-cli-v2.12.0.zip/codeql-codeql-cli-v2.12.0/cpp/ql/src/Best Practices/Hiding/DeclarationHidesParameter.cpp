void f(int i) {
  for (int i = 0; i < 10; ++i) { //the loop variable hides the parameter to f()
    ...
  }
}

