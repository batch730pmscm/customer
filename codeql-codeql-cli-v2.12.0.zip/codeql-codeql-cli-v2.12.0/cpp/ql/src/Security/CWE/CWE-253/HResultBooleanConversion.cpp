LPMALLOC pMalloc;
HRESULT hr = CoGetMalloc(1, &pMalloc);

if (!hr)
{
    // code ...
}
