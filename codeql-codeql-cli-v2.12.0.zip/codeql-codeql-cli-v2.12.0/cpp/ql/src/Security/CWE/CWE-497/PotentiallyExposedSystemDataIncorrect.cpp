char* key = getenv("APP_KEY");

//...

fprintf(stderr, "Key not recognized: %s\n", key);