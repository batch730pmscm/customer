const char *message = "Hello";
char password[32];
char buffer[256];

memcpy(buffer, message, 256);
