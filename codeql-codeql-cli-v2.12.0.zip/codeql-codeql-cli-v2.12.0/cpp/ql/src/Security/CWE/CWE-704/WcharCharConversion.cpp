wchar_t* pSrc;

pSrc = (wchar_t*)"a"; // casting a byte-string literal "a" to a wide-character string