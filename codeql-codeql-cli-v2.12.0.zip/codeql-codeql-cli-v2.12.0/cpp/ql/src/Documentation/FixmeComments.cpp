int isEven(int n) {
	//FIXME: Is only correct for small values of n
	return n == 0 || n == 2;
}