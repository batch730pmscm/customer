lgtm,codescanning
* The query `cpp/implicit-bitfield-downcast` now accounts for C++ reference types, which leads to more true positive results.
