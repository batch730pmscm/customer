lgtm,codescanning
* Added `Function.hasTrailingReturnType` predicate to check whether a function was declared with a trailing return type.