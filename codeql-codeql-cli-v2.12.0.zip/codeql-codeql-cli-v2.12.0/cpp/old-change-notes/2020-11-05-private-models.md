lgtm,codescanning
* Various classes in `semmle.code.cpp.models.implementations` have been made private. Users should not depend on library implementation details.
* The `OperatorNewAllocationFunction`, `OperatorDeleteDeallocationFunction`, `Iterator` and `Snprintf` classes now have interfaces in `semmle.code.cpp.models.interfaces`.
