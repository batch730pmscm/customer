lgtm,codescanning
* The 'Comparison with wider type' (cpp/comparison-with-wider-type) query has been improved to produce fewer false positives.