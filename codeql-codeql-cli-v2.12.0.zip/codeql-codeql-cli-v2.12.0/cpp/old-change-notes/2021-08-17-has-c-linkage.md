lgtm,codescanning
* Added `RoutineType.hasCLinkage` predicate to check whether a function type has "C" language linkage.