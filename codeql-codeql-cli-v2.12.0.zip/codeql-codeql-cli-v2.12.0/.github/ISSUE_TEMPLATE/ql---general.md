---
name: General issue
about: Tell us if you think something is wrong or if you have a question
title: General issue
labels: question
assignees: ''

---

**Description of the issue**

<!-- Please explain briefly what is the problem.
If it is about a GitHub project, please include its URL. -->

